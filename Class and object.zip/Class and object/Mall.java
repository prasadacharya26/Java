import java.util.Scanner;

class Mall{
	public static void main(String []args){
		Scanner scanner = new Scanner(System.in);
		Clothes clothes = new Clothes();
		String[] name = new String[3];
		System.out.println("Enter brand name:");
		for(int i=0;i<3;i++){
			name[i]=scanner.nextLine();
		}
		System.out.println("");
		clothes.brand(name);
		System.out.println("");
		clothes.type="Shirt";
		clothes.discount=10;
		clothes.price=2000;
		clothes.size='M';
		clothes.color="blue";
		System.out.println("");
		System.out.println("Details");
		System.out.println("Type:"+clothes.type);
		System.out.println("Discount:"+clothes.discount+"%");
		System.out.println("Price:"+clothes.price);
		System.out.println("Size:"+clothes.size);
		System.out.println("Color:"+clothes.color);
	}
}