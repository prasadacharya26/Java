class Clothes{
	String type;
	byte discount;
	String category;
	short price;
	String color;
	char size;
	
	void brand(String[] name){
		System.out.println("Brand");
		for(int i=0;i<3;i++){
			System.out.print(name[i]+" ");
		}
	}
}