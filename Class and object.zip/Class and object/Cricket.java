import java.util.Scanner;

class Cricket{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		Team team = new Team();
		team.teamName();
		System.out.println("");
		System.out.println("Enter team name:");
		String name = scanner.nextLine();
		System.out.println("Enter team captain:");
		String captain = scanner.nextLine();
		System.out.println("Enter team coach:");
		String coach = scanner.nextLine();
		team.teamDetails(name,captain,coach);
		System.out.println("");
		System.out.println("Team name:"+team.name);
		System.out.println("Team type:"+team.type);
		System.out.println("Team rank:"+team.rank);
		System.out.println("");
		team.name = "India";
		team.type = "Test";
		team.rank = 1;
		System.out.println("Team name:"+team.name);
		System.out.println("Team type:"+team.type);
		System.out.println("Team rank:"+team.rank);
	}
}