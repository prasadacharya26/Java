class Team{
	String name;
	String type;
	byte rank;
	
	void teamName(){
		System.out.println("Team");
		System.out.println("India" + " " + "Australia" + " " + "England" + " " + "Sri Lanka");
	}
	
	void teamDetails(String name, String captain,String coach){
		System.out.println("Team name:"+ name);
		System.out.println("Team captain:"+ captain);
		System.out.println("Total coach:"+coach);
	}
	
}