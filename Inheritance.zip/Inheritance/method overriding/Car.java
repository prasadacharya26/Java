class Car extends Vechical{
	String name;
	
	void toDrive(){
		System.out.println("To drive");
	}
	@Override
	void getCompany(){
		System.out.println("Ford,TATA M");
	}
}