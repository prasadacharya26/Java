class Vechical extends AutoMobile{
	String name;
	
	void toTravel(){
		System.out.println("To travel");
	}
	@Override
	void getCompany(){
		System.out.println("Ford,TATA M,Hero MotoCorp Ltd");
	}
}