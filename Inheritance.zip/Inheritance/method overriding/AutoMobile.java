class AutoMobile{
	String name;
	
	void getCompany(){
		System.out.println("Ford,TATA M,Maruti Suzuki,Hero MotoCorp Ltd");
	}
}