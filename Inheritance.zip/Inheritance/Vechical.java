class Vechical extends AutoMobile{
	String name;
	
	void toTravel(){
		System.out.println("To travel");
	}
}