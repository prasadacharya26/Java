class Gears extends AutoMobile{
	String name;
	
	void toSafety(){
		System.out.println("To safe");
	}
}