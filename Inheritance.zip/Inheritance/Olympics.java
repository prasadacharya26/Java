class Olympics{

}