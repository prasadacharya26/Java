class Tester{
	public static void main(String[] args){
		Indoor indoor = new Indoor();
		indoor.gamesDetails();
		indoor.games();
	}
}