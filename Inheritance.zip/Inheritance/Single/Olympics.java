class Olympics{
	void games(){
		System.out.println("Indoor and Outdoor");
	}
}