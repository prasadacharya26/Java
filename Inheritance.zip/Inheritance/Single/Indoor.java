class Indoor extends Olympics{
	void gamesDetails(){
		System.out.println("Chess ,Basketball ");
	}
}