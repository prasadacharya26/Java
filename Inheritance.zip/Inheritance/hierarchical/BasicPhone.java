class BasicPhone extends Phone{
	String name;
	float price;
	
	void service(){
		System.out.println("call and message service");
	}
}