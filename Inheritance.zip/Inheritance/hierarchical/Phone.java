class Phone{
	String name;
	float price;
	
	void typeOfPhone(){
		System.out.println("Basic and smart phone");
	}
}