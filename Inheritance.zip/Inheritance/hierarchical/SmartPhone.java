class SmartPhone extends Phone{
	String name;
	float price;
	
	void features(){
		System.out.println("Internet connectivity,embedded memory");
	}
}