class Tester{
	public static void main(String[] args){
		SmartPhone smart = new SmartPhone();
		smart.features();
		BasicPhone basic =new BasicPhone();
		basic.service();
	}
}