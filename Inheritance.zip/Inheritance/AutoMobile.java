class AutoMobile{
	String name;
	
	void speed(){
		System.out.println("Average speed 60");
	}
}