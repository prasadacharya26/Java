class Car extends Vechical{
	String name;
	
	void toDrive(){
		System.out.println("To drive");
	}
}