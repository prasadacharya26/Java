class Dance extends Culture{
	String type;
	short firstPrice;
	short secondPrice;
	
	void typeOfDance(){
		System.out.println("Group dance, solo dance");
	}
}