class Compitition{
	String type;
	short firstPrice;
	short secondPrice;
	
	void event(){
		System.out.println("Events");
	}
}