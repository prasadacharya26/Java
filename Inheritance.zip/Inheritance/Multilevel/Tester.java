class Tester{
	public static void main(String[] args){
		Dance dance = new Dance();
		dance.typeOfDance();
		dance.program();
		dance.event();
	}
}