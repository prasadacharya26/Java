class Culture extends Compitition{
	String type;
	short firstPrice;
	short secondPrice;
	
	void program(){
		System.out.println("Cultural program");
	}
}