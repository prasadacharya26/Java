class Home{
	public static void main(String[] args){
		short price = 4000;
		Furniture furniture = new Furniture("Sofa","Luxury",price);
		furniture.details();
	}
}