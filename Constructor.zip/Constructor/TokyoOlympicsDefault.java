class TokyoOlympicsDefault{
	public static void main(String[] args){
		Country country = new Country();
		country.details();
	}
}