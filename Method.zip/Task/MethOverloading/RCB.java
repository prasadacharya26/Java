class RCB{
	static void players(){
		System.out.println("Virat Kohli");
		System.out.println("AB de Villiers");
		System.out.println("Devdutt Padikkal");
		System.out.println("Maxwell");
	}
	static void players(String player5,String player6){
		System.out.println(player5);
		System.out.println(player6);
	}
	static void players(String player7,String player8,String player9){
		System.out.println(player7);
		System.out.println(player8);
		System.out.println(player9);
	}
	static void coach(String name){
		System.out.println("Coach:" + name);
	}
}