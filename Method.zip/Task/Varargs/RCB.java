class RCB{
	static void players(String... team){
		for(String player:team){
			System.out.println(player);
		}
	}
}