import java.util.Scanner;

class IPL{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter total match won:");
		int n = scanner.nextInt();
		RCB.point(n);
	}
}