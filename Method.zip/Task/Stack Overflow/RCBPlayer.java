class RCBPlayer{
	static void player(String name){
		System.out.println(name);
		player(name);
	}
}